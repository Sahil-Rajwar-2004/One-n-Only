"""
`weight`:       `KiloGram`, `Gram`, `Pound`\n
`temperature`:  `Celsius`, `Kelvin`, `Fahrenheit`\n
`length`:       `Meter`, `CentiMeter`, `KiloMeter`, `MilliMeter`, `Foot`\n
`pressure`:     `Bar`, `Pascal`, `Torr`, `Atm`\n
`magnetic`:     `Tesla`, `Gauss`\n
"""
